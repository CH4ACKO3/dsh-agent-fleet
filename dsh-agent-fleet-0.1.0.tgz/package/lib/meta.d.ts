import type { Agent } from '@deepseek-ai/dsh-agent';
import type { FleetAssistantMode, FleetAssistantRuntime } from './assistant.js';
export interface FleetMetaAssistantServiceOptions {
    readonly directory?: string;
}
/** Persist the small set of Sessions that belong to the workspace-free Fleet Help persona. */
export declare class FleetMetaAssistantService {
    private readonly assistant;
    private readonly directory;
    constructor(assistant: FleetAssistantRuntime, options?: FleetMetaAssistantServiceOptions);
    activate(agent: Agent): FleetAssistantMode;
    restore(agent: Agent): FleetAssistantMode | undefined;
    private markerPath;
}
//# sourceMappingURL=meta.d.ts.map