import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { FleetAssistantRuntime } from './assistant.js';
import { FleetConfigurationRegistry } from './configuration.js';
import type { CreateRunInput, FleetRunRecord } from './run.js';
import type { FleetWebSetupUploadInput, FleetWebUploadedResource } from '@dsh-agent-fleet/core/web';
export type FleetSetupPhase = 'setup' | 'creating' | 'operating';
export interface FleetSetupRecord {
    readonly setupId: string;
    readonly assistantSessionId: string;
    readonly projectRoot: string;
    readonly phase: FleetSetupPhase;
    readonly initialIdea?: string;
    readonly configuration?: Record<string, unknown>;
    readonly runId?: string;
    readonly lastError?: string;
    readonly updatedAt: string;
}
export interface FleetSetupServiceOptions {
    readonly directory?: string;
    readonly configuration?: FleetConfigurationRegistry;
}
interface FleetSetupRunService {
    create(launcher: Agent, input: CreateRunInput): Promise<FleetRunRecord>;
    findBySetupId(setupId: string, projectRoot: string): FleetRunRecord | undefined;
}
export interface BeginFleetSetupInput {
    readonly initialIdea?: string;
}
export interface StageFleetSetupInput {
    readonly configuration: unknown;
}
export interface FleetSetupCreation {
    readonly setup: FleetSetupRecord;
    readonly run: FleetRunRecord;
}
export declare function normalizeFleetSetupConfiguration(value: unknown, configuration?: FleetConfigurationRegistry): Record<string, unknown>;
export declare class FleetSetupService {
    private readonly assistant;
    private readonly runs;
    private readonly directory;
    private readonly configuration;
    private readonly creations;
    constructor(assistant: FleetAssistantRuntime, runs: FleetSetupRunService, options?: FleetSetupServiceOptions);
    begin(agent: Agent, input?: BeginFleetSetupInput): FleetSetupRecord;
    restore(agent: Agent): FleetSetupRecord | undefined;
    inspect(agent: Agent): FleetSetupRecord;
    stage(agent: Agent, input: StageFleetSetupInput): FleetSetupRecord;
    create(agent: Agent): Promise<FleetSetupCreation>;
    workspaceEntries(agent: Agent): Array<{
        readonly name: string;
        readonly type: 'file' | 'directory' | 'other';
    }>;
    uploadResource(agent: Agent, input: FleetWebSetupUploadInput): FleetWebUploadedResource;
    private createOnce;
    private reconcile;
    private require;
    private read;
    private write;
    private recordPath;
    private configPath;
    private sessionKey;
}
export declare function installSetupTool(ctx: Context, service: FleetSetupService): void;
export {};
//# sourceMappingURL=setup.d.ts.map