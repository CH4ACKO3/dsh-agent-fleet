export interface FleetArchiveTeam {
    readonly id: string;
    readonly name: string;
    readonly projectRoot: string;
    readonly status: string;
}
export interface FleetArchiveContributorContext {
    readonly team: FleetArchiveTeam;
    readonly directory: string;
}
export interface FleetArchiveRestoreContext extends FleetArchiveContributorContext {
    readonly sourceTeam: FleetArchiveTeam;
    /** Source member Session id to imported member Session id. */
    readonly sessionIdMap: Readonly<Record<string, string>>;
}
export interface FleetArchiveRestoreIdentity {
    readonly sourceTeam: FleetArchiveTeam;
    readonly sessionIdMap: Readonly<Record<string, string>>;
}
export interface FleetArchiveContributor {
    readonly id: string;
    save(context: FleetArchiveContributorContext): Promise<void> | void;
    restore(context: FleetArchiveRestoreContext): Promise<void> | void;
}
export interface FleetArchiveRestoreReport {
    readonly missing: readonly string[];
    readonly failed: readonly {
        readonly id: string;
        readonly error: string;
    }[];
}
export declare class FleetArchiveRegistry {
    private readonly contributors;
    register(contributor: FleetArchiveContributor): () => void;
    ids(): string[];
    save(team: FleetArchiveTeam, root: string): Promise<string[]>;
    restore(team: FleetArchiveTeam, root: string, identity?: FleetArchiveRestoreIdentity): Promise<FleetArchiveRestoreReport>;
}
//# sourceMappingURL=archive.d.ts.map