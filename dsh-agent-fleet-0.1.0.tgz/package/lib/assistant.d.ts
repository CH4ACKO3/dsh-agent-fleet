import type { Agent } from '@deepseek-ai/dsh-agent';
import type { FleetMemberView } from './member-view.js';
export declare const FLEET_ASSISTANT_TOOL_NAMES: readonly ["fleet_assistant", "fleet_run", "fleet_trace", "fleet_activity", "fleet_member"];
export declare const FLEET_GUIDE_TOOL_NAMES: readonly ["fleet_setup", "ask_user_question"];
export type FleetAssistantView = FleetMemberView;
declare const FLEET_MEMBER_TOOL_NAMES: {
    readonly messages: readonly ["fleet_send", "fleet_followup", "fleet_messages", "fleet_wait"];
    readonly coordination: readonly ["fleet_channel", "fleet_vote", "fleet_meeting"];
    readonly resources: readonly ["fleet_shared", "fleet_work", "fleet_resource", "fleet_workspace"];
    readonly status: readonly ["fleet_member_status"];
};
type FleetAssistantToolGroup = keyof typeof FLEET_MEMBER_TOOL_NAMES;
export declare const FLEET_TEAM_BUILDER_PROMPT: string;
export declare const FLEET_META_ASSISTANT_SYSTEM_PROMPT: string;
export declare const FLEET_ASSISTANT_SYSTEM_PROMPT: string;
export interface FleetAssistantMode {
    readonly active: boolean;
    readonly phase: 'inactive' | 'meta' | 'setup' | 'operating';
    readonly sessionId: string;
    readonly tools: string[];
    readonly setupId?: string;
    readonly runId?: string;
    readonly view?: FleetAssistantView;
}
export declare class FleetAssistantRuntime {
    private readonly toolGroupAvailable;
    private readonly active;
    constructor(toolGroupAvailable?: (group: FleetAssistantToolGroup) => boolean);
    activate(agent: Agent, runId?: string, view?: FleetAssistantView): FleetAssistantMode;
    activateMeta(agent: Agent): FleetAssistantMode;
    activateGuide(agent: Agent, setupId: string): FleetAssistantMode;
    promote(agent: Agent, runId: string, view?: FleetAssistantView): FleetAssistantMode;
    private install;
    deactivate(agent: Agent): FleetAssistantMode;
    status(agent: Agent): FleetAssistantMode;
    disposed(agentId: string): void;
    close(): void;
    private describe;
}
export {};
//# sourceMappingURL=assistant.d.ts.map