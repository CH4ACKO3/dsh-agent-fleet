import type { Context } from '@deepseek-ai/cordis';
import type { FleetMemberView } from './member-view.js';
export type FleetAuthorizationSubjectKind = 'member' | 'assistant' | 'external' | 'system';
export interface FleetAuthorizationSubject {
    readonly kind: FleetAuthorizationSubjectKind;
    readonly id: string;
}
export interface FleetAuthorizationResource {
    readonly kind: string;
    readonly id: string;
}
export interface FleetAuthorizationInput {
    readonly teamId: string;
    readonly subject: FleetAuthorizationSubject;
    readonly action: string;
    readonly resource?: FleetAuthorizationResource;
}
export interface FleetAuthorizationActor {
    readonly teamId: string;
    readonly subject: FleetAuthorizationSubject;
}
export interface FleetEffectiveAuthorization {
    readonly toolGroups: readonly string[];
    readonly actions: readonly string[];
    readonly op: boolean;
}
export interface FleetActionPolicyInput {
    readonly teamId: string;
    readonly member: FleetMemberView;
    readonly base: FleetEffectiveAuthorization;
}
export interface FleetActionPolicy {
    resolve(input: FleetActionPolicyInput): FleetEffectiveAuthorization | undefined;
}
export interface FleetResourcePolicy {
    authorize(input: FleetAuthorizationInput, baseline: boolean): boolean;
}
export interface FleetAuthorizationBaseline {
    resolveSubject(teamId: string, subject: FleetAuthorizationSubject): FleetMemberView | undefined;
    actorForAgent?(agentId: string): FleetAuthorizationActor | undefined;
    authorizeAction?(input: FleetAuthorizationInput): boolean;
    authorizeResource(input: FleetAuthorizationInput): boolean;
}
export interface FleetRegisteredAction {
    readonly id: string;
    readonly description: string;
}
export interface FleetAuthorizationNamespace {
    readonly namespace: string;
    readonly actions: readonly FleetRegisteredAction[];
    /** Default local action ids used when no action-policy plugin replaces this member's profile. */
    readonly defaultActions?: (input: {
        readonly teamId: string;
        readonly member: FleetMemberView;
    }) => readonly string[];
    /** Optional safe default for non-member subjects such as external integrations. */
    readonly authorizeBaseline?: (input: FleetAuthorizationInput) => boolean;
    /** Install for every member even when none of this namespace's actions are granted. */
    readonly alwaysVisible?: boolean;
    readonly installTools?: (ctx: Context, input: {
        readonly teamId: string;
        readonly projectRoot: string;
        readonly member: FleetMemberView;
        readonly hasMember: (member: string) => boolean;
        readonly authorization: FleetEffectiveAuthorization;
    }) => (() => void) | void;
}
export interface FleetAuthorizationResourceKind {
    readonly kind: string;
    /** Feature-owned safe default used when no resource-policy plugin overrides it. */
    readonly authorizeBaseline?: (input: FleetAuthorizationInput) => boolean;
}
export interface FleetAuthorizationChange {
    readonly teamId?: string;
    readonly members?: readonly string[];
}
export declare class FleetAuthorizationService {
    private readonly contributions;
    private readonly listeners;
    private readonly builtinActions;
    private readonly resourceKinds;
    private actionPolicy;
    private resourcePolicy;
    private baseline;
    registerNamespace(contribution: FleetAuthorizationNamespace): () => void;
    registerResourceKind(input: string | FleetAuthorizationResourceKind): () => void;
    installBaseline(baseline: FleetAuthorizationBaseline): () => void;
    installActionPolicy(policy: FleetActionPolicy): () => void;
    installResourcePolicy(policy: FleetResourcePolicy): () => void;
    resolve(teamId: string, member: FleetMemberView): FleetEffectiveAuthorization;
    authorize(input: FleetAuthorizationInput): boolean;
    actorForAgent(agentId: string): FleetAuthorizationActor | undefined;
    require(input: FleetAuthorizationInput): void;
    has(teamId: string, member: FleetMemberView, action: string): boolean;
    namespaces(): FleetAuthorizationNamespace[];
    actionIds(): string[];
    resourceKindIds(): string[];
    visible(contribution: FleetAuthorizationNamespace, authorization: FleetEffectiveAuthorization): boolean;
    onChange(listener: (change: FleetAuthorizationChange) => void): () => void;
    changed(change: FleetAuthorizationChange): void;
}
//# sourceMappingURL=authorization.d.ts.map