import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { TypertContribution } from '@deepseek-ai/dsh-typert-registry/types';
import { FLEET_WEB_INVOCATIONS, FLEET_WEB_REMOTE, type FleetWebSetupUploadInput } from '@dsh-agent-fleet/core/web';
import type { FleetMemberView } from './member-view.js';
import type { FleetRunService, FleetWorkStatus } from './run.js';
import type { FleetSetupService } from './setup.js';
export interface FleetWebProjectInput {
    readonly teamId: string;
    readonly view?: 'team' | 'member' | 'trace' | 'resource' | 'configuration';
    readonly member?: string;
    readonly resource?: string;
    readonly revision?: string;
    readonly tail?: boolean;
    readonly afterSequence?: number;
    readonly limit?: number;
}
export interface FleetWebSendInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly mode: 'conversation' | 'relay';
    readonly text: string;
    readonly to?: `@${string}` | `#${string}` | `meeting:${string}`;
    readonly kind?: 'collaboration' | 'directive';
    readonly mentions?: readonly string[];
    readonly resources?: readonly string[];
    readonly delivery?: 'quiet' | 'wakeup' | 'interrupt';
}
export interface FleetWebMemberInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly action: 'add' | 'update' | 'pause' | 'resume' | 'remove';
    readonly member?: string;
    readonly view?: FleetMemberView;
}
export interface FleetWebControlInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly action: 'start' | 'finish' | 'pause' | 'resume' | 'close';
    readonly taskPath?: string;
    readonly status?: Exclude<FleetWorkStatus, 'running'>;
    readonly summary?: string;
}
export interface FleetWebUploadInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly name: string;
    readonly base64: string;
    readonly label?: string;
    readonly mediaType?: string;
}
export interface FleetWebArchiveInput {
    readonly sessionId: string;
    readonly action: 'export' | 'read' | 'begin_import' | 'write' | 'finish_import' | 'cancel';
    readonly teamId?: string;
    readonly includeWorkspace?: boolean;
    readonly transferId?: string;
    readonly offset?: number;
    readonly base64?: string;
    readonly name?: string;
    readonly projectRoot?: string;
    readonly importMode?: 'copy' | 'restore';
}
export { FLEET_WEB_INVOCATIONS, FLEET_WEB_REMOTE };
export declare const FLEET_WEB_LOCAL: TypertContribution;
export declare class FleetWebRemote extends TypertRemoteService {
    private readonly host;
    private readonly runs;
    private readonly setups;
    private readonly archiveTransfers;
    constructor(host: Context, runs: FleetRunService, setups: FleetSetupService);
    list(signal: AbortSignal): import("./run.js").FleetRunRecord[];
    project(input: FleetWebProjectInput, signal: AbortSignal): Record<string, unknown> | import("./run.js").FleetTeamProjection | import("./run.js").FleetMemberProjection | Promise<import("./run.js").FleetResourcePreview> | Promise<{
        readonly runId: string;
        readonly member: string;
        readonly events: import("./run.js").FleetTraceEvent[];
        readonly hasMore: boolean;
    }>;
    send(input: FleetWebSendInput, signal: AbortSignal): import("@dsh-agent-fleet/message").SendMessageResult | import("./run.js").FleetAssistantMessage;
    member(input: FleetWebMemberInput, signal: AbortSignal): Promise<import("./run.js").FleetRunMember>;
    control(input: FleetWebControlInput, signal: AbortSignal): Promise<import("./run.js").FleetRunRecord>;
    upload(input: FleetWebUploadInput, signal: AbortSignal): import("@dsh-agent-fleet/resources").FleetResource;
    uploadSetup(input: FleetWebSetupUploadInput, signal: AbortSignal): import("@dsh-agent-fleet/core/web").FleetWebUploadedResource;
    archive(input: FleetWebArchiveInput, signal: AbortSignal): Promise<import("./run.js").FleetArchiveImportResult | {
        base64: string;
        nextOffset: number;
        done: boolean;
    } | {
        transferId: `${string}-${string}-${string}-${string}-${string}`;
        name: string;
        size: number;
        cancelled?: never;
        nextOffset?: never;
    } | {
        transferId: `${string}-${string}-${string}-${string}-${string}`;
        name?: never;
        size?: never;
        cancelled?: never;
        nextOffset?: never;
    } | {
        cancelled: boolean;
        transferId?: never;
        name?: never;
        size?: never;
        nextOffset?: never;
    } | {
        nextOffset: number;
        transferId?: never;
        name?: never;
        size?: never;
        cancelled?: never;
    }>;
    private requireArchiveTransfer;
    private removeArchiveTransfer;
    private caller;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetWeb: FleetWebRemote;
    }
}
//# sourceMappingURL=web.d.ts.map