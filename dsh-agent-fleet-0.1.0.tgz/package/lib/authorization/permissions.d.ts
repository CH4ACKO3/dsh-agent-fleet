import type { Context } from '@deepseek-ai/cordis';
import { type FleetMemberView } from '../member-view.js';
import type { FleetActionPolicyInput, FleetActionPolicy, FleetAuthorizationService, FleetEffectiveAuthorization } from '../authorization.js';
import type { FleetRunService } from '../run.js';
import { type FleetAuthorizationGroup, type FleetGroupService } from './groups.js';
export declare const FLEET_PERMISSIONS_CONFIGURATION_MODULE = "dsh-agent-fleet/authorization/permissions";
export declare const FLEET_PERMISSIONS_STATE_NAMESPACE = "authorization-permissions";
export interface FleetPermissionAssignment {
    readonly grants: readonly string[];
    readonly denies: readonly string[];
    readonly toolGroups: readonly string[];
    readonly denyToolGroups: readonly string[];
    readonly op?: boolean;
}
export interface FleetPermissionGroup extends FleetAuthorizationGroup {
    readonly toolGroups: readonly string[];
    readonly denyToolGroups?: readonly string[];
    readonly actions: readonly string[];
    readonly denies?: readonly string[];
    readonly op?: boolean;
}
export interface FleetMemberAccess extends FleetPermissionAssignment {
    readonly groups: readonly string[];
}
export interface FleetPermissionState {
    readonly version: 1;
    readonly groups: Readonly<Record<string, FleetPermissionAssignment>>;
}
export declare const FLEET_PERMISSION_PRESETS: readonly FleetPermissionGroup[];
export declare function parseFleetPermissionConfiguration(value: unknown): FleetPermissionState;
export declare class FleetPermissionService implements FleetActionPolicy {
    private readonly runs;
    private readonly authorization;
    private readonly groupService;
    private readonly states;
    constructor(runs: FleetRunService, authorization: FleetAuthorizationService, groupService: FleetGroupService);
    state(teamId: string): FleetPermissionState;
    groups(teamId: string): FleetPermissionGroup[];
    resolve(input: FleetActionPolicyInput): FleetEffectiveAuthorization | undefined;
    member(teamId: string, member: string): FleetMemberAccess | undefined;
    memberForAgent(teamId: string, agentId: string): FleetMemberView | undefined;
    memberView(teamId: string, member: string): FleetMemberView | undefined;
    setMember(teamId: string, member: string, value: FleetMemberAccess): FleetMemberAccess;
    resetMember(teamId: string, member: string): void;
    setOp(teamId: string, member: string, op: boolean): FleetMemberAccess;
    upsertGroup(teamId: string, value: FleetPermissionGroup): FleetPermissionGroup;
    deleteGroup(teamId: string, groupId: string): void;
    canManage(teamId: string, member: FleetMemberView): boolean;
    private requireMember;
    private configurationState;
    private save;
}
export declare function applyPermissions(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetPermissions: FleetPermissionService;
    }
}
//# sourceMappingURL=permissions.d.ts.map