import type { Context } from '@deepseek-ai/cordis';
import type { FleetAuthorizationInput, FleetResourcePolicy } from '../authorization.js';
import type { FleetRunService } from '../run.js';
import { type FleetGroupService } from './groups.js';
export declare const FLEET_ACCESS_STATE_NAMESPACE = "authorization-access";
export declare const FLEET_ACCESS_LEVELS: readonly ["read", "write", "use", "manage"];
export type FleetAccessLevel = typeof FLEET_ACCESS_LEVELS[number];
export type FleetAccessScope = 'self' | 'tree';
export type FleetAccessEffect = 'allow' | 'deny';
export interface FleetAccessPrincipal {
    readonly kind: 'group';
    readonly id: string;
}
export interface FleetAccessResourceAdapter {
    readonly kind: string;
    levelFor(action: string): FleetAccessLevel | undefined;
    normalize(teamId: string, resourceId: string): string;
    contains?(teamId: string, parentId: string, childId: string): boolean;
}
export interface FleetAccessMode {
    readonly principal: FleetAccessPrincipal;
    readonly resourceKind: string;
    readonly mode: 'restricted';
}
export interface FleetAccessRule {
    readonly id: string;
    readonly principal: FleetAccessPrincipal;
    readonly resource: {
        readonly kind: string;
        readonly id: string;
    };
    readonly scope: FleetAccessScope;
    readonly effect: FleetAccessEffect;
    readonly levels: readonly FleetAccessLevel[];
}
export interface FleetAccessState {
    readonly version: 1;
    readonly modes: readonly FleetAccessMode[];
    readonly rules: readonly FleetAccessRule[];
}
export interface PutFleetAccessRule {
    readonly id?: string;
    readonly principal: FleetAccessPrincipal;
    readonly resource: {
        readonly kind: string;
        readonly id: string;
    };
    readonly scope?: FleetAccessScope;
    readonly effect: FleetAccessEffect;
    readonly levels: readonly FleetAccessLevel[];
}
export declare class FleetAccessService implements FleetResourcePolicy {
    private readonly runs;
    private readonly groups;
    private readonly states;
    private readonly adapters;
    constructor(runs: FleetRunService, groups: FleetGroupService);
    registerAdapter(adapter: FleetAccessResourceAdapter): () => void;
    adapterKinds(): string[];
    state(teamId: string): FleetAccessState;
    mode(teamId: string, principalValue: FleetAccessPrincipal, resourceKind: string): 'inherit' | 'restricted';
    setMode(teamId: string, principalValue: FleetAccessPrincipal, resourceKind: string, mode: 'inherit' | 'restricted'): void;
    rules(teamId: string, principalValue?: FleetAccessPrincipal): FleetAccessRule[];
    putRule(teamId: string, input: PutFleetAccessRule): FleetAccessRule;
    removeRule(teamId: string, id: string): void;
    removeGroups(teamId: string, groups: readonly string[]): void;
    authorize(input: FleetAuthorizationInput, baseline: boolean): boolean;
    private requireAdapter;
    private requirePrincipal;
    private projectRoot;
    private save;
}
export declare function applyAccess(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetAccess: FleetAccessService;
    }
}
//# sourceMappingURL=access.d.ts.map