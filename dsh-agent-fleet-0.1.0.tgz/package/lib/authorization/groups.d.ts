import type { Context } from '@deepseek-ai/cordis';
import type { FleetRunService } from '../run.js';
export declare const FLEET_GROUPS_STATE_NAMESPACE = "authorization-groups";
export declare const FLEET_GROUPS_CONFIGURATION_MODULE = "dsh-agent-fleet/authorization/groups";
export interface FleetAuthorizationGroup {
    readonly id: string;
    readonly name: string;
    readonly parents: readonly string[];
    readonly preset?: boolean;
    readonly private?: boolean;
}
export interface FleetGroupState {
    readonly version: 1;
    readonly groups: readonly FleetAuthorizationGroup[];
    readonly members: Readonly<Record<string, readonly string[]>>;
}
export interface FleetGroupChange {
    readonly teamId: string;
    readonly members?: readonly string[];
    readonly removedGroups?: readonly string[];
}
export declare const FLEET_GROUP_PRESETS: readonly FleetAuthorizationGroup[];
export declare function fleetPrivateGroupId(member: string): string;
export declare function isFleetPrivateGroupId(group: string): boolean;
export declare function parseFleetGroupConfiguration(value: unknown): FleetGroupState;
export declare class FleetGroupService {
    private readonly runs;
    private readonly states;
    private readonly listeners;
    constructor(runs: FleetRunService);
    state(teamId: string): FleetGroupState;
    groups(teamId: string): FleetAuthorizationGroup[];
    privateGroup(member: string): FleetAuthorizationGroup;
    membership(teamId: string, member: string): string[];
    expanded(teamId: string, member: string): string[];
    setMembership(teamId: string, member: string, groups: readonly string[], notify?: boolean): string[];
    resetMembership(teamId: string, member: string, notify?: boolean): void;
    upsertGroup(teamId: string, value: FleetAuthorizationGroup, notify?: boolean): FleetAuthorizationGroup;
    deleteGroup(teamId: string, groupId: string, notify?: boolean): void;
    onChange(listener: (change: FleetGroupChange) => void): () => void;
    private configurationState;
    private validate;
    private save;
    private changed;
}
export declare function applyGroups(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetGroups: FleetGroupService;
    }
}
//# sourceMappingURL=groups.d.ts.map