import type { Context } from '@deepseek-ai/cordis';
export * from './access.js';
export * from './groups.js';
export * from './permissions.js';
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map