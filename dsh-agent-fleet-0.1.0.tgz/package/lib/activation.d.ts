import type { Context } from '@deepseek-ai/cordis';
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent';
import type { UserMessage } from '@deepseek-ai/dsh-session';
import type { FleetSetupCreation, FleetSetupRecord, FleetSetupService } from './setup.js';
import type { FleetAssistantRuntime } from './assistant.js';
import type { FleetMetaAssistantService } from './meta.js';
import type { FleetRunService } from './run.js';
interface FleetActivationSetups {
    begin(agent: Agent, input?: {
        readonly initialIdea?: string;
    }): FleetSetupRecord;
    stage(agent: Agent, input: {
        readonly configuration: unknown;
    }): FleetSetupRecord;
    create(agent: Agent): Promise<FleetSetupCreation>;
}
interface FleetConnectionServices {
    readonly runs: Pick<FleetRunService, 'attachAssistant' | 'sendConversationMessage'>;
    readonly assistant: Pick<FleetAssistantRuntime, 'activate'>;
    readonly meta: Pick<FleetMetaAssistantService, 'activate'>;
}
/** Activate a staged Fleet request and return clean messages for the durable turn. */
export declare function activateFleetFromMessages(setups: FleetActivationSetups, agent: Agent, messages: readonly UserMessage[], signal?: AbortSignal, connection?: FleetConnectionServices): Promise<PreStepDecision>;
/** Install the one-shot UI activation bridge on the native Agent loop. */
export declare function installFleetActivationBridge(ctx: Context, setups: FleetSetupService, runs: FleetRunService, assistant: FleetAssistantRuntime, meta: FleetMetaAssistantService): void;
export {};
//# sourceMappingURL=activation.d.ts.map