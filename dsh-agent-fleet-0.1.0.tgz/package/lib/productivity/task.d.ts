import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetMemberDirectory } from '@dsh-agent-fleet/core';
export declare const FLEET_TASK_STATE_NAMESPACE = "productivity-tasks";
export type FleetProjectTaskStatus = 'open' | 'in_progress' | 'blocked' | 'completed' | 'cancelled';
export type FleetProjectTaskPriority = 'low' | 'normal' | 'high';
export interface FleetTaskEntry {
    readonly id: string;
    readonly kind: 'comment' | 'progress';
    readonly author: string;
    readonly text: string;
    readonly resources: string[];
    readonly createdAt: string;
}
export interface FleetProjectTask {
    readonly id: string;
    readonly title: string;
    readonly description: string;
    readonly status: FleetProjectTaskStatus;
    readonly priority: FleetProjectTaskPriority;
    readonly createdBy: string;
    readonly assignees: string[];
    readonly reviewers: string[];
    readonly followers: string[];
    readonly dependencies: string[];
    readonly parentId?: string;
    readonly dueAt?: string;
    readonly resources: string[];
    readonly entries: FleetTaskEntry[];
    readonly createdAt: string;
    readonly updatedAt: string;
    readonly completedAt?: string;
    readonly dueNotifiedAt?: string;
}
export interface FleetTaskState {
    readonly version: 1;
    readonly tasks: readonly FleetProjectTask[];
}
export interface FleetProjectTaskEvent {
    readonly action: 'created' | 'updated' | 'commented' | 'progressed' | 'completed' | 'reopened' | 'due';
    readonly task: FleetProjectTask;
    readonly actor?: string;
}
export interface CreateFleetProjectTaskInput {
    readonly title: string;
    readonly description?: string;
    readonly priority?: FleetProjectTaskPriority;
    readonly assignees?: readonly string[];
    readonly reviewers?: readonly string[];
    readonly followers?: readonly string[];
    readonly dependencies?: readonly string[];
    readonly parentId?: string;
    readonly dueAt?: string;
    readonly resources?: readonly string[];
}
export interface UpdateFleetProjectTaskInput {
    readonly title?: string;
    readonly description?: string;
    readonly status?: Exclude<FleetProjectTaskStatus, 'completed'>;
    readonly priority?: FleetProjectTaskPriority;
    readonly assignees?: readonly string[];
    readonly reviewers?: readonly string[];
    readonly followers?: readonly string[];
    readonly dependencies?: readonly string[];
    readonly dueAt?: string;
    readonly resources?: readonly string[];
}
export declare function parseFleetTaskState(value: JsonValue | undefined): FleetTaskState;
export declare class FleetTaskBoard {
    private readonly directory;
    private readonly canManage;
    private readonly onDue;
    private readonly tasks;
    private readonly timers;
    private readonly listeners;
    private active;
    private closed;
    constructor(directory: FleetMemberDirectory, canManage?: (agentId: string) => boolean, onDue?: (task: FleetProjectTask) => void);
    state(): FleetTaskState;
    restore(state: FleetTaskState): void;
    activate(): void;
    pause(): void;
    list(callerId: string, input?: {
        readonly status?: FleetProjectTaskStatus;
        readonly assignee?: string;
        readonly parentId?: string;
    }): FleetProjectTask[];
    get(callerId: string, id: string): FleetProjectTask;
    create(callerId: string, input: CreateFleetProjectTaskInput): FleetProjectTask;
    update(callerId: string, id: string, input: UpdateFleetProjectTaskInput): FleetProjectTask;
    addEntry(callerId: string, id: string, kind: FleetTaskEntry['kind'], text: string, resources?: readonly string[]): FleetProjectTask;
    complete(callerId: string, id: string): FleetProjectTask;
    reopen(callerId: string, id: string): FleetProjectTask;
    retireMember(member: string, successor: string): void;
    onEvent(listener: (event: FleetProjectTaskEvent) => void): () => void;
    close(): void;
    private triggerDue;
    private arm;
    private replace;
    private emit;
    private member;
    private resolve;
    private resolveMany;
    private strings;
    private taskReferences;
    private dependsOn;
    private date;
    private requireTask;
    private requireResponsible;
    private assertOpen;
}
export declare function installTaskTools(ctx: Context, tasks: FleetTaskBoard, authorize: (agentId: string, action: string) => boolean): () => void;
//# sourceMappingURL=task.d.ts.map