import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetMemberDirectory } from '@dsh-agent-fleet/core';
export declare const FLEET_CALENDAR_STATE_NAMESPACE = "productivity-calendar";
export type FleetCalendarRsvp = 'invited' | 'accepted' | 'declined' | 'tentative';
export type FleetCalendarEventStatus = 'scheduled' | 'open' | 'closed' | 'cancelled';
export interface FleetCalendarEvent {
    readonly id: string;
    readonly title: string;
    readonly agenda: string;
    readonly organizer: string;
    readonly attendees: string[];
    readonly rsvps: Record<string, FleetCalendarRsvp>;
    readonly startAt: string;
    readonly endAt?: string;
    readonly repeatMinutes?: number;
    readonly occurrence: number;
    readonly status: FleetCalendarEventStatus;
    readonly meetingId?: string;
    readonly lastStartedAt?: string;
    readonly lastMeetingClosedAt?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface FleetCalendarState {
    readonly version: 1;
    readonly events: FleetCalendarEvent[];
}
export interface FleetCalendarEventChange {
    readonly action: 'created' | 'updated' | 'rsvp' | 'started' | 'closed' | 'cancelled';
    readonly event: FleetCalendarEvent;
    readonly actor?: string;
}
export interface CreateFleetCalendarEventInput {
    readonly title: string;
    readonly agenda: string;
    readonly attendees: readonly string[];
    readonly startAt: string;
    readonly endAt?: string;
    readonly repeatMinutes?: number;
}
export declare function parseFleetCalendarState(value: JsonValue | undefined): FleetCalendarState;
export declare class FleetCalendar {
    private readonly directory;
    private readonly onStart;
    private readonly canManage;
    private readonly events;
    private readonly timers;
    private readonly listeners;
    private active;
    private closed;
    constructor(directory: FleetMemberDirectory, onStart: (event: FleetCalendarEvent) => string | undefined, canManage?: (agentId: string) => boolean);
    state(): FleetCalendarState;
    restore(state: FleetCalendarState): void;
    activate(): void;
    pause(): void;
    list(callerId: string, from?: string, to?: string): FleetCalendarEvent[];
    get(callerId: string, id: string): FleetCalendarEvent;
    create(callerId: string, input: CreateFleetCalendarEventInput): FleetCalendarEvent;
    update(callerId: string, id: string, input: {
        readonly title?: string;
        readonly agenda?: string;
        readonly attendees?: readonly string[];
        readonly startAt?: string;
        readonly endAt?: string;
    }): FleetCalendarEvent;
    rsvp(callerId: string, id: string, response: Exclude<FleetCalendarRsvp, 'invited'>): FleetCalendarEvent;
    closeEvent(callerId: string, id: string): FleetCalendarEvent;
    cancel(callerId: string, id: string): FleetCalendarEvent;
    retireMember(retired: string, successor: string): void;
    freeBusy(callerId: string, members: readonly string[], from: string, to: string): Array<{
        readonly member: string;
        readonly events: FleetCalendarEvent[];
    }>;
    pendingStarts(): FleetCalendarEvent[];
    retryPendingStarts(): void;
    linkMeeting(id: string, meetingId: string): FleetCalendarEvent;
    closeLinkedMeeting(meetingId: string, closedAt?: string): FleetCalendarEvent | undefined;
    onEvent(listener: (event: FleetCalendarEventChange) => void): () => void;
    close(): void;
    private trigger;
    private arm;
    private replace;
    private emit;
    private member;
    private resolve;
    private requireOrganizer;
    private requireEvent;
    private date;
    private assertOpen;
}
export declare function installCalendarTools(ctx: Context, calendar: FleetCalendar, authorize: (agentId: string, action: string) => boolean): () => void;
//# sourceMappingURL=calendar.d.ts.map