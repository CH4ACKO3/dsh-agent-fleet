import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetMemberDirectory } from '@dsh-agent-fleet/core';
export declare const FLEET_SCHEDULE_STATE_NAMESPACE = "productivity-schedules";
export type FleetScheduledTaskStatus = 'scheduled' | 'due' | 'completed' | 'cancelled';
export interface FleetScheduledTask {
    readonly id: string;
    readonly title: string;
    readonly instructions: string;
    readonly createdBy: string;
    readonly assignees: string[];
    readonly status: FleetScheduledTaskStatus;
    readonly dueAt: string;
    readonly repeatMinutes?: number;
    readonly lastTriggeredAt?: string;
    readonly completedAt?: string;
    readonly cancelledAt?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface FleetScheduleState {
    readonly version: 1;
    readonly schedules: readonly FleetScheduledTask[];
}
export interface CreateFleetScheduledTaskInput {
    readonly title: string;
    readonly instructions?: string;
    readonly dueAt: string;
    readonly assignees?: readonly string[];
    readonly repeatMinutes?: number;
}
export interface FleetScheduledTaskEvent {
    readonly action: 'created' | 'updated' | 'triggered' | 'completed' | 'cancelled';
    readonly task: FleetScheduledTask;
    readonly actor?: string;
}
export declare function parseFleetScheduleState(value: JsonValue | undefined): FleetScheduleState;
export declare class FleetScheduler {
    private readonly directory;
    private readonly canManage;
    private readonly onDue;
    private readonly tasks;
    private readonly timers;
    private readonly listeners;
    private active;
    private closed;
    constructor(directory: FleetMemberDirectory, canManage: (agentId: string) => boolean, onDue: (task: FleetScheduledTask) => void);
    state(): FleetScheduleState;
    restore(state: FleetScheduleState): void;
    activate(): void;
    pause(): void;
    list(callerId: string): FleetScheduledTask[];
    create(callerId: string, input: CreateFleetScheduledTaskInput): FleetScheduledTask;
    complete(callerId: string, id: string): FleetScheduledTask;
    cancel(callerId: string, id: string): FleetScheduledTask;
    retireMember(retired: string, successor: string): void;
    onEvent(listener: (event: FleetScheduledTaskEvent) => void): () => void;
    close(): void;
    private trigger;
    private arm;
    private replace;
    private futureDate;
    private nextOccurrence;
    private resolveAssignees;
    private member;
    private requireResponsible;
    private requireTask;
    private assertOpen;
    private emit;
}
export declare function installScheduleTools(ctx: Context, scheduler: FleetScheduler, authorize: (agentId: string, action: string) => boolean): () => void;
//# sourceMappingURL=schedule.d.ts.map