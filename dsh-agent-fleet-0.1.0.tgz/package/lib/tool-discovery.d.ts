import type { Context } from '@deepseek-ai/cordis';
import type { FleetMemberToolGroup } from './member-view.js';
interface FleetToolCatalogEntry {
    readonly name: string;
    readonly group: FleetMemberToolGroup;
    readonly description: string;
    readonly keywords: string;
    readonly actions: readonly string[];
    readonly privilegedActions?: Readonly<Record<string, string | readonly string[]>>;
    readonly constraints?: readonly string[];
}
export declare function searchFleetTools(query: string, allowedGroups: ReadonlySet<FleetMemberToolGroup>, loadedGroups: ReadonlySet<FleetMemberToolGroup>, permissions?: ReadonlySet<string>): Array<Omit<FleetToolCatalogEntry, 'keywords' | 'actions' | 'privilegedActions' | 'constraints'> & {
    readonly loaded: boolean;
    readonly actions: string[];
    readonly restrictedActions: Array<{
        readonly action: string;
        readonly permissions: string[];
    }>;
    readonly constraints: string[];
}>;
export declare function installFleetToolDiscovery(ctx: Context, options: {
    readonly allowedGroups: ReadonlySet<FleetMemberToolGroup>;
    readonly loadedGroups: Set<FleetMemberToolGroup>;
    readonly permissions: ReadonlySet<string>;
    readonly load: (group: FleetMemberToolGroup) => (() => void) | void;
}): () => void;
export {};
//# sourceMappingURL=tool-discovery.d.ts.map