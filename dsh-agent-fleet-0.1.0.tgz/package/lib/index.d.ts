import type { Context } from '@deepseek-ai/cordis';
import * as Core from '@dsh-agent-fleet/core';
import * as Message from '@dsh-agent-fleet/message';
import * as Resources from '@dsh-agent-fleet/resources';
import * as Authorization from './authorization/index.js';
import * as Data from './data/index.js';
import { FleetArchiveRegistry } from './archive.js';
import { FleetAssistantRuntime } from './assistant.js';
import { FleetAuthorizationService } from './authorization.js';
import { FleetCollaborationService } from './collaboration.js';
import { FleetConfigurationRegistry } from './configuration.js';
import { FleetMetaAssistantService } from './meta.js';
import { FleetRunService } from './run.js';
import { FleetSetupService } from './setup.js';
export { Authorization, Core, Data, Message, Resources };
export * from './authorization/index.js';
export * from './data/index.js';
export * from './authorization.js';
export * from './assistant.js';
export * from './archive.js';
export * from './activation.js';
export * from './collaboration.js';
export * from './configuration.js';
export * from './member-view.js';
export * from './tool-discovery.js';
export * from './meta.js';
export * from './run.js';
export * from './setup.js';
export * from './web.js';
export declare const name = "dsh-agent-fleet";
export declare function apply(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetAssistant: FleetAssistantRuntime;
        fleetArchives: FleetArchiveRegistry;
        fleetAuthorization: FleetAuthorizationService;
        fleetCollaboration: FleetCollaborationService;
        fleetConfiguration: FleetConfigurationRegistry;
        fleetMetaAssistant: FleetMetaAssistantService;
        fleetRuns: FleetRunService;
        fleetSetups: FleetSetupService;
    }
}
//# sourceMappingURL=index.d.ts.map