export declare const FLEET_MESSAGE_MODULE = "dsh-agent-fleet/message";
export declare const FLEET_RESOURCES_MODULE = "dsh-agent-fleet/resources";
export declare const FLEET_UI_MODULE = "dsh-agent-fleet/ui";
export type FleetConfigurationValue = null | boolean | number | string | FleetConfigurationValue[] | {
    [key: string]: FleetConfigurationValue;
};
export interface FleetConfigurationModule {
    readonly id: string;
    parse(value: unknown): unknown;
}
export interface FleetMessageConfiguration {
    readonly defaultChannel: {
        readonly id: string;
        readonly name: string;
    };
    readonly rules: string;
    readonly collaborationMethod: string;
}
export interface FleetResourcesConfiguration {
    readonly policy: string;
    readonly items: readonly {
        readonly path: string;
        readonly label?: string;
        readonly mediaType?: string;
    }[];
}
export interface FleetUiConfiguration {
    readonly userAccess: {
        readonly updateDensity: 'concise' | 'balanced' | 'detailed';
        readonly notificationPolicy: 'decisions' | 'milestones' | 'continuous';
        readonly contentPreference: string;
    };
    readonly editor?: FleetConfigurationValue;
}
export declare function fleetConfigurationValue(value: unknown, label?: string): FleetConfigurationValue;
export declare function parseFleetMessageConfiguration(value: unknown): FleetMessageConfiguration;
export declare function parseFleetResourcesConfiguration(value: unknown): FleetResourcesConfiguration;
export declare function parseFleetUiConfiguration(value: unknown): FleetUiConfiguration;
export declare class FleetConfigurationRegistry {
    private readonly modules;
    constructor();
    register(module: FleetConfigurationModule): () => void;
    parse(value: unknown): Record<string, FleetConfigurationValue>;
}
//# sourceMappingURL=configuration.d.ts.map