import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetCore } from '@dsh-agent-fleet/core';
import type { FleetMemberStatusBoard } from '@dsh-agent-fleet/core';
import type { FleetCoordinationEvent, FleetTarget, MessageHub, SendMessageResult } from '@dsh-agent-fleet/message';
import type { FleetResources } from '@dsh-agent-fleet/resources';
import type { FleetResourceEvent } from '@dsh-agent-fleet/resources';
import type { FleetResource } from '@dsh-agent-fleet/resources';
import { FleetArchiveRegistry } from './archive.js';
import type { FleetArchiveRestoreReport } from './archive.js';
import type { FleetAuthorizationBaseline, FleetAuthorizationService } from './authorization.js';
import type { FleetAssistantRuntime, FleetAssistantView } from './assistant.js';
import type { FleetCollaborationService } from './collaboration.js';
import { FleetConfigurationRegistry, type FleetConfigurationValue } from './configuration.js';
import type { FleetMemberContacts, FleetMemberPermission, FleetMemberToolGroup, FleetMemberView } from './member-view.js';
export type FleetRunStatus = 'starting' | 'idle' | 'running' | 'paused' | 'finishing' | 'closed' | 'failed';
export type FleetWorkStatus = 'running' | 'finished' | 'blocked' | 'failed' | 'cancelled';
export interface FleetWorkRecord {
    readonly id: string;
    readonly taskPath: string;
    readonly status: FleetWorkStatus;
    readonly startedAt: string;
    readonly endedAt?: string;
    readonly summary?: string;
}
export interface FleetRunMember {
    readonly name: string;
    readonly displayName?: string;
    readonly color?: string;
    readonly role: string;
    readonly sessionId: string;
    readonly provider?: string;
    readonly model?: string;
    readonly status?: 'idle' | 'running' | 'waiting' | 'error' | 'offline' | 'paused' | 'unknown';
}
export interface FleetRunAssistant {
    readonly sessionId: string;
    readonly view: FleetAssistantView;
    readonly status?: 'idle' | 'running' | 'offline';
}
export interface FleetRunRecord {
    readonly id: string;
    readonly sourceSetupId?: string;
    readonly team: string;
    readonly name: string;
    readonly configPath: string;
    readonly projectRoot: string;
    /** @deprecated Legacy Teams may retain their former dedicated coordinator id. */
    readonly coordinator?: string;
    /** @deprecated Use assistants. Kept while existing persisted Teams migrate. */
    readonly launcherSessionId: string;
    readonly agentOptions?: {
        readonly provider?: string;
        readonly model?: string;
        readonly maxTokens?: number;
    };
    readonly members: FleetRunMember[];
    readonly assistants: FleetRunAssistant[];
    readonly status: FleetRunStatus;
    /** Members stopped by the current Team-level pause. Individually paused members are not included. */
    readonly teamPausedMembers?: string[];
    /** Runtime projection only; omitted from persisted run.json records. */
    readonly runtimeState?: 'active' | 'dormant';
    readonly work?: FleetWorkRecord;
    readonly settled: boolean;
    readonly startedAt: string;
    readonly endedAt?: string;
    readonly summary?: string;
    readonly error?: string;
}
export interface FleetTraceEvent {
    readonly sequence: number;
    readonly createdAt: string;
    readonly scope: 'team' | 'member';
    readonly member?: string;
    readonly sourceSequence?: number;
    readonly type: string;
    readonly data: string;
}
export interface FleetJournalEvent {
    readonly sequence: number;
    readonly createdAt: string;
    readonly scope: 'team' | 'member';
    readonly member?: string;
    readonly sourceSequence?: number;
    readonly type: string;
    readonly data: unknown;
}
export interface FleetTeamProjection {
    readonly run: FleetRunRecord;
    readonly memberViews: FleetMemberView[];
    readonly events: FleetJournalEvent[];
    readonly hasMore: boolean;
}
export interface FleetMemberProjection {
    readonly run: FleetRunRecord;
    readonly view: FleetMemberView;
    readonly events: FleetJournalEvent[];
    readonly hasMore: boolean;
}
export interface FleetResourcePreview {
    readonly id: string;
    readonly kind: 'markdown' | 'text';
    readonly body: string;
    readonly mediaType?: string;
    readonly size?: number;
    readonly history: readonly FleetResourceRevisionSummary[];
    readonly historyTruncated: boolean;
    readonly revision?: FleetResourceRevisionDetail;
}
export interface FleetResourceRevisionSummary {
    readonly id: string;
    readonly updatedBy: string;
    readonly updatedAt: string;
    readonly operation: 'created' | 'updated';
    readonly available: boolean;
    readonly size: number;
}
export interface FleetResourceRevisionDetail extends FleetResourceRevisionSummary {
    readonly before: string | null;
    readonly after: string;
}
export type FleetActivityKind = 'message' | 'task' | 'calendar' | 'meeting' | 'vote' | 'document' | 'schedule' | 'member';
export interface FleetActivityItem {
    readonly id: string;
    readonly sequence: number;
    readonly createdAt: string;
    readonly kind: FleetActivityKind;
    readonly type: string;
    readonly acknowledged: boolean;
    readonly data: Record<string, JsonValue>;
}
export interface FleetActivityInbox {
    readonly runId: string;
    readonly member: string;
    readonly items: FleetActivityItem[];
    readonly hasMore: boolean;
}
export type FleetAssistantMessageKind = 'collaboration' | 'directive';
export interface FleetAssistantMessage {
    readonly id: string;
    readonly runId: string;
    readonly kind: FleetAssistantMessageKind;
    readonly text: string;
    readonly recipients: string[];
    readonly assistantSessionId: string;
    readonly assistantId: string;
    readonly assistantName: string;
    readonly createdAt: string;
}
export interface FleetRunServiceOptions {
    readonly registryDirectory?: string;
    readonly archives?: FleetArchiveRegistry;
    readonly authorization?: FleetAuthorizationService;
    readonly configuration?: FleetConfigurationRegistry;
}
export interface ExportFleetArchiveInput {
    readonly runId: string;
    readonly destination: string;
    readonly includeWorkspace?: boolean;
}
export interface FleetArchiveExportResult {
    readonly path: string;
    readonly teamId: string;
    readonly includesWorkspace: boolean;
    readonly extensions: readonly string[];
}
export interface ImportFleetArchiveInput {
    readonly archivePath: string;
    readonly projectRoot: string;
    /** Restore keeps archive identities; copy creates a new Team and member Sessions. */
    readonly mode?: 'restore' | 'copy';
}
export interface FleetArchiveImportResult {
    readonly run: FleetRunRecord;
    readonly extensions: FleetArchiveRestoreReport;
}
export interface CreateRunInput {
    readonly configPath: string;
    readonly projectRoot: string;
    readonly requiredPaths: readonly string[];
    readonly sourceSetupId?: string;
    readonly provider?: string;
    readonly model?: string;
    readonly maxTokens?: number;
}
interface StartRunInput {
    readonly runId?: string;
    readonly taskPath: string;
    readonly projectRoot: string;
}
interface ResumeRunInput {
    readonly runId: string;
    readonly projectRoot: string;
}
export interface SendAssistantMessageInput {
    readonly runId?: string;
    readonly kind: FleetAssistantMessageKind;
    readonly text: string;
    readonly projectRoot?: string;
}
export interface SendFleetConversationMessageInput {
    readonly runId: string;
    readonly to: FleetTarget;
    readonly text: string;
    readonly replyTo?: string;
    readonly resources?: readonly string[];
    readonly mentions?: readonly string[];
    readonly delivery: 'quiet' | 'wakeup' | 'interrupt';
}
export interface UploadFleetResourceInput {
    readonly runId: string;
    readonly name: string;
    readonly base64: string;
    readonly label?: string;
    readonly mediaType?: string;
}
export interface AttachAssistantInput {
    readonly runId?: string;
    readonly projectRoot?: string;
    readonly assistantId?: string;
    readonly id?: string;
    readonly name?: string;
    readonly color?: string;
    readonly role?: string;
    readonly responsibility?: string;
    readonly prompt?: string;
    readonly provider?: string;
    readonly model?: string;
    readonly toolGroups?: readonly FleetMemberToolGroup[];
    readonly permissions?: readonly FleetMemberPermission[];
    readonly contacts?: FleetMemberContacts;
}
export interface AddFleetMemberInput {
    readonly runId: string;
    readonly view: FleetMemberView;
}
export interface UpdateFleetMemberInput {
    readonly runId: string;
    readonly member: string;
    readonly view: FleetMemberView;
}
export declare class FleetRunService {
    private readonly ctx;
    private readonly core;
    private readonly collaboration;
    private readonly records;
    private readonly voteWorkIds;
    private readonly dormantRunIds;
    private readonly eventSequences;
    private readonly teamProjectionEvents;
    private readonly memberViewSnapshots;
    private readonly waiters;
    private readonly finalizations;
    private readonly resumingRunIds;
    private readonly networkRecoveries;
    private readonly memberToolActivity;
    private readonly waitingSessionIds;
    private readonly abnormalSessionIds;
    private readonly changeListeners;
    private readonly registryDirectory;
    private readonly archives;
    private readonly authorization;
    private readonly configuration;
    constructor(ctx: Context, core: FleetCore, collaboration: FleetCollaborationService, options?: FleetRunServiceOptions);
    subscribeChanges(listener: () => void): () => void;
    authorizationBaseline(): FleetAuthorizationBaseline;
    create(launcher: Agent, input: CreateRunInput): Promise<FleetRunRecord>;
    start(launcher: Agent, input: StartRunInput): FleetRunRecord;
    resume(launcher: Agent, input: ResumeRunInput): Promise<FleetRunRecord>;
    list(projectRoot?: string): FleetRunRecord[];
    findBySetupId(setupId: string, projectRoot: string): FleetRunRecord | undefined;
    status(runId?: string, projectRoot?: string): FleetRunRecord;
    messageHub(runId: string): MessageHub;
    requireAssistantConnection(caller: Agent, runId: string, allowDormant?: boolean): FleetRunAssistant;
    resourceStore(runId: string): FleetResources;
    memberStatusBoard(runId: string): FleetMemberStatusBoard;
    memberViews(runId: string): FleetMemberView[];
    memberViewForAgent(runId: string, agentId: string): FleetMemberView | undefined;
    readExtensionState(runId: string, namespace: string): JsonValue | undefined;
    writeExtensionState(runId: string, namespace: string, value: JsonValue): void;
    moduleConfiguration(runId: string, moduleId: string): FleetConfigurationValue | undefined;
    exportConfiguration(runId: string): Record<string, unknown>;
    exportArchive(caller: Agent, input: ExportFleetArchiveInput): Promise<FleetArchiveExportResult>;
    importArchive(caller: Agent, input: ImportFleetArchiveInput): Promise<FleetArchiveImportResult>;
    private effectiveMemberViews;
    addMember(caller: Agent, input: AddFleetMemberInput): Promise<FleetRunMember>;
    updateMember(caller: Agent, input: UpdateFleetMemberInput): Promise<FleetRunMember>;
    removeMember(caller: Agent, runId: string, memberName: string): Promise<FleetRunMember>;
    pauseTeam(caller: Agent, runId?: string): Promise<FleetRunRecord>;
    resumeTeam(caller: Agent, runId?: string): Promise<FleetRunRecord>;
    pauseMember(caller: Agent, runId: string, memberName: string): Promise<FleetRunMember>;
    resumeMember(caller: Agent, runId: string, memberName: string): Promise<FleetRunMember>;
    private requireFleetPermission;
    attachAssistant(caller: Agent, input?: AttachAssistantInput): Promise<{
        readonly run: FleetRunRecord;
        readonly assistant: FleetRunAssistant;
    }>;
    detachAssistant(caller: Agent, runId?: string): FleetRunRecord;
    sendAssistantMessage(caller: Agent, input: SendAssistantMessageInput): FleetAssistantMessage;
    sendConversationMessage(caller: Agent, input: SendFleetConversationMessageInput): SendMessageResult;
    sendUserConversationMessage(input: SendFleetConversationMessageInput): SendMessageResult;
    uploadResource(caller: Agent, input: UploadFleetResourceInput): FleetResource;
    wait(runId: string | undefined, timeoutMs: number, signal?: AbortSignal, projectRoot?: string): Promise<FleetRunRecord>;
    finish(caller: Agent, status: Exclude<FleetWorkStatus, 'running'>, summary: string, runId?: string): FleetRunRecord;
    end(caller: Agent, summary: string, runId?: string): FleetRunRecord;
    recordCoordination(runId: string, event: FleetCoordinationEvent): void;
    recordResource(runId: string, event: FleetResourceEvent): void;
    private clearMemberActivity;
    private refreshMemberActivity;
    private recordMemberActivity;
    private recordMemberHealth;
    recordMemberSessionEvent(sessionId: string, event: SessionEvent): void;
    agentIdle(agent: Agent): void;
    agentStatusChanged(agent: Agent): void;
    agentDisconnected(agentId: string): void;
    private networkRoute;
    private scheduleNetworkRecovery;
    private wakeNetworkRecoveriesForRoute;
    private wakeNetworkRecovery;
    private clearNetworkRecovery;
    private clearRunNetworkRecoveries;
    readTrace(runId: string | undefined, afterSequence: number, limit: number, projectRoot?: string): {
        readonly runId: string;
        readonly events: FleetTraceEvent[];
        readonly hasMore: boolean;
    };
    readTeamProjection(runId: string, afterSequence: number, limit: number): FleetTeamProjection;
    readWebTeamProjection(runId: string, afterSequence: number, limit: number): FleetTeamProjection;
    readResourcePreview(runId: string, resourceId: string, signal?: AbortSignal, revisionId?: string): Promise<FleetResourcePreview>;
    readMemberTrace(runId: string | undefined, memberName: string, afterSequence: number, limit: number, projectRoot?: string): Promise<{
        readonly runId: string;
        readonly member: string;
        readonly events: FleetTraceEvent[];
        readonly hasMore: boolean;
    }>;
    readMemberTraceTail(runId: string | undefined, memberName: string, limit: number, projectRoot?: string): Promise<{
        readonly runId: string;
        readonly member: string;
        readonly events: FleetTraceEvent[];
        readonly hasMore: boolean;
    }>;
    readMemberProjection(runId: string, memberName: string, afterSequence: number, limit: number): FleetMemberProjection;
    private projectMember;
    activityInbox(caller: Agent, input?: {
        readonly runId?: string;
        readonly afterSequence?: number;
        readonly limit?: number;
        readonly unreadOnly?: boolean;
    }): FleetActivityInbox;
    acknowledgeActivity(caller: Agent, sequence: number, runId?: string): FleetActivityItem;
    private activityKind;
    private journalEvent;
    private visibleToMember;
    close(): void;
    private settleFinishedWork;
    private setTerminal;
    private settleInterruptedTerminal;
    private finalize;
    private requireParticipant;
    private describeRecord;
    private requireRecord;
    private requireCallerRecord;
    private requireMutableRecord;
    private requireRuntime;
    private activeTeamIds;
    private openCollaboration;
    private runtimeMemberName;
    private memberArchiveId;
    private participants;
    private assistantTeamForSession;
    private liveMember;
    private memberCanReply;
    private replaceRecord;
    private writeRecord;
    private appendEvent;
    private emitChange;
    private cacheTeamProjection;
    private lastStoredSequence;
    private storedEvents;
    private storedResourceRevisionSummaries;
    private storedResourceRevision;
    private collaborationState;
    private restoreAssistantRebinds;
    private restoredSessionId;
    private loadPersistedTeams;
    private openDormantTeam;
    private readTeamReference;
    private rememberTeam;
    private forgetTeam;
    private teamReferencePath;
    private runDirectory;
    private extensionStatePath;
    private persistence;
    private requirePersistence;
    private notify;
}
export declare function installRunTools(ctx: Context, service: FleetRunService, assistant: FleetAssistantRuntime): void;
export {};
//# sourceMappingURL=run.d.ts.map