import type { Context } from '@deepseek-ai/cordis';
import { FleetMemberStatusBoard } from '@dsh-agent-fleet/core';
import type { FleetMemberStatusEvent } from '@dsh-agent-fleet/core';
import { MessageHub } from '@dsh-agent-fleet/message';
import type { FleetCoordinationEvent, SendMessageInput, SendMessageResult } from '@dsh-agent-fleet/message';
import { FleetResources } from '@dsh-agent-fleet/resources';
import type { FleetResourceEvent } from '@dsh-agent-fleet/resources';
import type { FleetMemberView } from './member-view.js';
import type { FleetAuthorizationService } from './authorization.js';
import { FleetTaskBoard, type FleetProjectTaskEvent, type FleetTaskState } from './productivity/task.js';
import { FleetScheduler, type FleetScheduleState, type FleetScheduledTaskEvent } from './productivity/schedule.js';
import { FleetCalendar, type FleetCalendarEventChange, type FleetCalendarState } from './productivity/calendar.js';
export interface FleetCollaborationTeam {
    readonly id: string;
    readonly messages: MessageHub;
    readonly resources: FleetResources;
    readonly memberStatuses: FleetMemberStatusBoard;
    readonly tasks: FleetTaskBoard;
    readonly scheduler: FleetScheduler;
    readonly calendar: FleetCalendar;
    readonly memberViews: ReadonlyMap<string, FleetMemberView>;
    readonly memberIdsByName: Map<string, string>;
    readonly memberNamesById: Map<string, string>;
    attachMember(agentId: string, view: FleetMemberView): void;
    rebindMember(previousAgentId: string, agentId: string, view: FleetMemberView): void;
    detachMember(agentId: string): void;
    updateMemberView(view: FleetMemberView): void;
    removeMemberView(member: string): void;
    retireMember(input: {
        readonly agentId: string;
        readonly member: string;
        readonly successorAgentId: string;
        readonly successor: string;
    }): void;
    sendUserMessage(input: SendMessageInput): SendMessageResult;
    installTools(ctx: Context, member: string, options?: {
        readonly exposeHostFleetTools?: boolean;
    }): () => void;
    refreshAccess(member?: string): void;
    activateProductivity(): void;
    pauseProductivity(): void;
    restoreProductivity(input: {
        readonly tasks: FleetTaskState;
        readonly schedules: FleetScheduleState;
        readonly calendar: FleetCalendarState;
    }): void;
    restore(input: {
        readonly coordination: readonly FleetCoordinationEvent[];
        readonly resources: Parameters<FleetResources['restoreResources']>[0];
        readonly memberStatuses: readonly FleetMemberStatusEvent[];
    }): void;
    close(): void;
}
export interface OpenFleetCollaborationTeamInput {
    readonly id: string;
    readonly memberViews: readonly FleetMemberView[];
    readonly projectRoot: string;
    readonly sharedDirectory: string;
    readonly onCoordination: (event: FleetCoordinationEvent) => void;
    readonly onResource: (event: FleetResourceEvent) => void;
    readonly onMemberStatus: (event: FleetMemberStatusEvent) => void;
    readonly onTask?: (event: FleetProjectTaskEvent, state: FleetTaskState) => void;
    readonly onSchedule?: (event: FleetScheduledTaskEvent, state: FleetScheduleState) => void;
    readonly onCalendar?: (event: FleetCalendarEventChange, state: FleetCalendarState) => void;
}
export declare class FleetCollaborationService {
    private readonly ctx;
    private readonly authorization;
    private readonly teams;
    private readonly pendingAccessRefresh;
    private readonly stopAccess;
    private readonly stopStatus;
    private readonly stopStep;
    private readonly stopNamespaces;
    constructor(ctx: Context, authorization: FleetAuthorizationService);
    private authorizeMember;
    private scheduleAccessRefresh;
    private flushAccessRefresh;
    open(input: OpenFleetCollaborationTeamInput): FleetCollaborationTeam;
    has(id: string): boolean;
    get(id: string): FleetCollaborationTeam | undefined;
    require(id: string): FleetCollaborationTeam;
    ids(): string[];
    entries(): Array<[string, FleetCollaborationTeam]>;
    closeTeam(id: string): void;
    close(): void;
}
//# sourceMappingURL=collaboration.d.ts.map