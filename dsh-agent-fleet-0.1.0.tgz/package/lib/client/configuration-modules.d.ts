import type { ComponentType } from 'react';
export declare const FLEET_MESSAGE_CONFIGURATION_MODULE = "dsh-agent-fleet/message";
export declare const FLEET_RESOURCES_CONFIGURATION_MODULE = "dsh-agent-fleet/resources";
export declare const FLEET_UI_CONFIGURATION_MODULE = "dsh-agent-fleet/ui";
export interface FleetConfigurationModuleEditorProps {
    readonly value: unknown;
    readonly onChange: (value: unknown) => void;
}
export interface FleetConfigurationTemplateContribution {
    readonly id: string;
    readonly nameZh: string;
    readonly nameEn: string;
    readonly sourceZh?: string;
    readonly sourceEn?: string;
    readonly configuration: unknown;
}
export interface FleetConfigurationModuleContribution {
    readonly id: string;
    readonly labelZh: string;
    readonly labelEn: string;
    readonly order?: number;
    readonly defaultValue?: unknown;
    readonly Editor?: ComponentType<FleetConfigurationModuleEditorProps>;
    readonly templates?: readonly FleetConfigurationTemplateContribution[];
}
export declare class FleetConfigurationModuleRegistry {
    private readonly modules;
    private readonly listeners;
    private snapshot;
    readonly subscribe: (listener: () => void) => (() => void);
    readonly getSnapshot: () => readonly FleetConfigurationModuleContribution[];
    register(contribution: FleetConfigurationModuleContribution): () => void;
    valuesWithDefaults(values: Readonly<Record<string, unknown>>): Record<string, unknown>;
    private publish;
}
export declare const fleetConfigurationModules: FleetConfigurationModuleRegistry;
//# sourceMappingURL=configuration-modules.d.ts.map