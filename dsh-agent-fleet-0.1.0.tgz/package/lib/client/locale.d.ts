export declare function resolveChineseLocale(documentLanguage: string, navigatorLanguage: string): boolean;
export declare function isChineseLocale(): boolean;
//# sourceMappingURL=locale.d.ts.map