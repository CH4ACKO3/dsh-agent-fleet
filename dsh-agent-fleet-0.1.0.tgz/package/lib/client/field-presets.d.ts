export type FieldPresetTarget = 'positioning' | 'rules' | 'collaboration' | 'content' | 'resources';
export interface FieldContentPreset {
    readonly id: string;
    readonly name: readonly [zh: string, en: string];
    readonly detail: readonly [zh: string, en: string];
}
export type FieldPresetCollection = Readonly<Record<FieldPresetTarget, readonly FieldContentPreset[]>>;
export type FieldPresetImport = Readonly<Partial<Record<FieldPresetTarget, readonly FieldContentPreset[]>>>;
export declare function parseFieldPresetImport(value: unknown): FieldPresetImport | undefined;
export declare function mergeFieldPresetImport(current: FieldPresetCollection, imported: FieldPresetImport): FieldPresetCollection;
//# sourceMappingURL=field-presets.d.ts.map