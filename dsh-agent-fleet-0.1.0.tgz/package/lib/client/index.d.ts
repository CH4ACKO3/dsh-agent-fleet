import type { ComponentType, ReactElement } from 'react';
export declare function FleetTeamButton({ sessionId: propSessionId }?: {
    readonly sessionId?: string;
}): ReactElement;
type NativeComponentProps = Record<string, unknown>;
/** Decorate the native composer without replacing its visuals or input-machine behavior. */
export declare function withFleetComposerActivation(InputBar: ComponentType<NativeComponentProps>): ComponentType<NativeComponentProps>;
export declare function withFleetTeamButton(AgentPresetSeat: ComponentType<NativeComponentProps>): ComponentType<NativeComponentProps>;
export declare const name = "dsh-agent-fleet";
export { FleetMetaAssistantHeaderButton, FleetMetaAssistantPinnedRow, withFleetMetaConversationRoot, withFleetMetaWorkspaceBrowser, } from './meta-assistant.js';
export { apply, FLEET_PANEL_SOURCE_SERVICE, FLEET_PANEL_SLOTS, FleetPanelToolButton, FleetNativeChatRuntimePrimer, FleetTeamPanel, inject, withFleetNativeChatView, } from './team-panel.js';
export type { FleetPanelActivity, FleetPanelConversation, FleetPanelHomeOwner, FleetPanelMember, FleetPanelMessage, FleetPanelMessageBlockOwner, FleetPanelMessageOwner, FleetPanelMemberTrace, FleetPanelMemberTraceEvent, FleetPanelPaneOwner, FleetPanelRenderSlot, FleetPanelResource, FleetPanelResourcePreviewOwner, FleetPanelSendInput, FleetPanelSidebarSectionOwner, FleetPanelSnapshot, FleetPanelSource, FleetPanelTeamDirectory, FleetPanelTeamGroup, FleetPanelTeamSnapshot, FleetPanelTeamSummary, FleetPanelToolId, FleetPanelToolOwner, } from './team-panel.js';
export { FleetChatAvatar, FleetChatDivider, FleetInfoHint, FleetChatMessage, FleetChatNotice, FleetChatReadReceipt, FleetPresenceLabel, FleetConversationHeader, } from './runtime-chat.js';
export { FLEET_MESSAGE_CONFIGURATION_MODULE, FLEET_RESOURCES_CONFIGURATION_MODULE, FLEET_UI_CONFIGURATION_MODULE, FleetConfigurationModuleRegistry, fleetConfigurationModules, } from './configuration-modules.js';
export type { FleetConfigurationModuleContribution, FleetConfigurationModuleEditorProps, FleetConfigurationTemplateContribution, } from './configuration-modules.js';
export type { FleetChatAvatarProps, FleetChatContentBlock, FleetChatDividerProps, FleetChatExtensionBlock, FleetChatImageBlock, FleetChatMember, FleetChatMentionBlock, FleetChatMessageProps, FleetChatNoticeProps, FleetChatResourceBlock, FleetChatReadReceiptData, FleetConversationHeaderProps, FleetConversationKind, FleetMessageDeliveryState, FleetPresence, } from './runtime-chat.js';
//# sourceMappingURL=index.d.ts.map