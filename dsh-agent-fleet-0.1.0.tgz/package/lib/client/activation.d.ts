import { type FleetActivationRequest } from '@dsh-agent-fleet/core/activation';
export interface StagedFleetActivation {
    readonly id: number;
    readonly sessionId: string;
    readonly request: FleetActivationRequest;
}
export interface FleetActivationClientSessions {
    readonly list: {
        getSnapshot(): {
            readonly current?: string;
        };
        subscribe(listener: () => void): () => void;
    };
}
export declare function configureFleetActivationSessions(next: FleetActivationClientSessions | undefined): void;
export declare function getCurrentFleetSessionId(): string | undefined;
export declare function subscribeCurrentFleetSession(listener: () => void): () => void;
export declare function stageFleetActivation(sessionId: string, request: FleetActivationRequest): StagedFleetActivation;
export declare function clearFleetActivation(sessionId: string, id?: number): void;
export declare function consumeFleetActivation(sessionId: string, text: string): string | undefined;
/** Restore a failed native submission without exposing the private envelope in the composer. */
export declare function recoverFleetActivationDraft(sessionId: string, text: string): string | undefined;
export declare function getFleetActivationSnapshot(sessionId: string | undefined): StagedFleetActivation | null;
export declare function subscribeFleetActivation(listener: () => void): () => void;
//# sourceMappingURL=activation.d.ts.map