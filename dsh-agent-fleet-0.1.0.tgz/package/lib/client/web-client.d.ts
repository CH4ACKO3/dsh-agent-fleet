import type { FleetWebUploadedResource } from '@dsh-agent-fleet/core/web';
import type { FleetWebClient } from '@dsh-agent-fleet/core/web';
export declare function configureFleetWebClient(next: FleetWebClient | undefined): void;
export declare function getFleetWebClient(): Promise<FleetWebClient>;
export declare function encodeFleetFile(buffer: ArrayBuffer): string;
export declare function uploadFleetSetupFile(sessionId: string, file: File, signal?: AbortSignal): Promise<FleetWebUploadedResource>;
//# sourceMappingURL=web-client.d.ts.map