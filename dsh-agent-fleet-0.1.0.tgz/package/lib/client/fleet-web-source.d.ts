import type { FleetWebClient } from '@dsh-agent-fleet/core/web';
import { type FleetPanelSource } from './team-panel.js';
export interface FleetWebPanelSource extends FleetPanelSource {
    refresh(): Promise<void>;
    invalidate(): Promise<void>;
    dispose(): void;
}
/** Cursor-based projection refreshed by the Fleet browser-peer notification channel. */
export declare function createFleetWebPanelSource(getClient: (signal?: AbortSignal) => Promise<FleetWebClient>): FleetWebPanelSource;
//# sourceMappingURL=fleet-web-source.d.ts.map