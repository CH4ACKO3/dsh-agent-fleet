import type { ComponentType, ReactElement, ReactNode } from 'react';
import { FLEET_WEB_PEER_LOCAL, FLEET_WEB_REMOTE } from '@dsh-agent-fleet/core/web';
import { type FleetChatContentBlock, type FleetChatMember } from './runtime-chat.js';
import { type FleetMetaClientSessions, type FleetMetaClientWorkspaces } from './meta-assistant.js';
export type FleetPanelToolId = 'chat' | 'team' | 'agent' | 'resources' | 'activity' | (string & {});
export interface FleetPanelConversation {
    readonly id: string;
    readonly kind: 'channel' | 'direct' | 'cross-team';
    readonly name: string;
    readonly topic?: string;
    readonly unread?: number;
    readonly peerId?: string;
    /** Stable Fleet member ids participating in a member-to-member direct conversation. */
    readonly participantIds?: readonly string[];
    readonly participantTeamIds?: readonly string[];
    readonly memberCount?: number;
    readonly activeCount?: number;
}
export interface FleetPanelMember extends FleetChatMember {
    readonly responsibility: string;
    /** Short, self-declared description of the work this member is currently doing. */
    readonly statusText?: string;
    readonly provider?: string;
    readonly model?: string;
    /** The native DSH Session owned by this persistent Fleet member. */
    readonly sessionId?: string;
    /** Conversations visible from this member's runtime perspective. Omit to expose the Team snapshot. */
    readonly visibleConversationIds?: readonly string[];
    readonly runtimeStatus?: 'idle' | 'running' | 'waiting' | 'error' | 'offline' | 'paused' | 'unknown';
}
export interface FleetPanelMessage {
    readonly id: string;
    readonly conversationId: string;
    readonly senderId: string;
    readonly senderTeamId?: string;
    readonly sender?: FleetChatMember;
    readonly sentAt: string;
    readonly content: readonly FleetChatContentBlock[];
    readonly receipt?: {
        readonly visibleMemberIds: readonly string[];
        readonly readMemberIds: readonly string[];
        readonly unreadMemberIds: readonly string[];
    };
}
export interface FleetPanelResource {
    readonly id: string;
    readonly name: string;
    readonly kind: 'plan' | 'checklist' | 'file';
    readonly path: string;
    readonly detail: string;
    readonly size?: number;
    readonly mediaType?: string;
    readonly body?: string;
    readonly updatedAt?: string;
}
export interface FleetPanelResourceContent {
    readonly id: string;
    readonly kind: 'markdown' | 'text';
    readonly body: string;
    readonly mediaType?: string;
    readonly size?: number;
    readonly history: readonly FleetPanelResourceRevisionSummary[];
    readonly historyTruncated: boolean;
    readonly revision?: FleetPanelResourceRevision;
}
export interface FleetPanelResourceRevisionSummary {
    readonly id: string;
    readonly updatedBy: string;
    readonly updatedAt: string;
    readonly operation: 'created' | 'updated';
    readonly available: boolean;
    readonly size: number;
}
export interface FleetPanelResourceRevision extends FleetPanelResourceRevisionSummary {
    readonly before: string | null;
    readonly after: string;
}
export interface FleetPanelWorkspace {
    readonly id: string;
    readonly name: string;
    readonly path: string;
    readonly access: 'read' | 'write';
    readonly members: readonly string[];
}
export interface FleetPanelActivity {
    readonly id: string;
    readonly kind: 'message' | 'resource' | 'decision' | 'member';
    readonly text: string;
    readonly createdAt: string;
}
export interface FleetPanelTeamSnapshot {
    readonly teamId: string;
    readonly teamName: string;
    readonly color?: string;
    readonly unread?: number;
    readonly status: 'starting' | 'idle' | 'running' | 'paused' | 'finishing' | 'closed' | 'failed' | 'disconnected';
    readonly runtimeState?: 'active' | 'dormant';
    readonly conversations: readonly FleetPanelConversation[];
    readonly members: readonly FleetPanelMember[];
    readonly messages: readonly FleetPanelMessage[];
    readonly resources: readonly FleetPanelResource[];
    readonly workspaces?: readonly FleetPanelWorkspace[];
    readonly activity: readonly FleetPanelActivity[];
}
export interface FleetPanelTeamSummary {
    readonly teamId: string;
    readonly teamName: string;
    readonly color?: string;
    readonly unread?: number;
    readonly needsAttention?: boolean;
    readonly primaryWorkspace?: string;
    readonly status: FleetPanelTeamSnapshot['status'];
    readonly runtimeState?: 'active' | 'dormant';
}
export interface FleetPanelTeamRunControl {
    readonly action: 'pause' | 'resume';
    readonly label: '暂停运行' | '继续运行';
    readonly busyLabel: '正在暂停…' | '正在继续…';
    readonly title: string;
}
export declare function fleetPanelTeamRunControl(team: Pick<FleetPanelTeamSummary, 'status' | 'runtimeState'>): FleetPanelTeamRunControl | undefined;
export interface FleetPanelTeamGroup {
    readonly id: string;
    readonly name: string;
    readonly teamIds: readonly string[];
    readonly kind: 'favorites' | 'custom' | 'ungrouped' | 'archived';
}
export interface FleetPanelTeamDirectory {
    readonly teams: readonly FleetPanelTeamSummary[];
    readonly groups: readonly FleetPanelTeamGroup[];
}
export interface FleetPanelSnapshot {
    readonly directory: FleetPanelTeamDirectory;
    readonly selectedTeamId?: string;
    readonly team?: FleetPanelTeamSnapshot;
    readonly connection?: {
        readonly status: 'loading' | 'connected' | 'disconnected';
        readonly error?: string;
        readonly updatedAt?: string;
    };
}
export interface FleetPanelMemberTraceEvent {
    readonly sequence: number;
    readonly createdAt: string;
    readonly type: string;
    readonly data: string;
}
export interface FleetPanelMemberTrace {
    readonly events: readonly FleetPanelMemberTraceEvent[];
    readonly truncated: boolean;
}
export interface FleetPanelSendInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly conversationId: string;
    readonly content: readonly FleetChatContentBlock[];
    readonly delivery?: 'quiet' | 'wakeup' | 'interrupt';
    readonly mentions?: readonly string[];
}
export interface FleetPanelUploadInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly file: File;
}
export interface FleetPanelTeamControlInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly action: 'pause' | 'resume' | 'close';
    readonly summary?: string;
}
export interface FleetPanelMemberControlInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly memberId: string;
    readonly action: 'pause' | 'resume';
}
export interface FleetPanelArchiveExportInput {
    readonly sessionId: string;
    readonly teamId: string;
    readonly includeWorkspace: boolean;
}
export interface FleetPanelArchiveImportInput {
    readonly sessionId: string;
    readonly file: File;
    readonly projectRoot: string;
    readonly mode: 'copy' | 'restore';
}
export interface FleetPanelArchiveFile {
    readonly name: string;
    readonly blob: Blob;
}
export interface FleetPanelSource {
    getSnapshot(): FleetPanelSnapshot;
    subscribe(listener: () => void): () => void;
    selectTeam(teamId: string): void;
    sendMessage(input: FleetPanelSendInput): Promise<void>;
    uploadResource?(input: FleetPanelUploadInput): Promise<void>;
    controlTeam?(input: FleetPanelTeamControlInput): Promise<void>;
    controlMember?(input: FleetPanelMemberControlInput): Promise<void>;
    exportTeam?(teamId: string, signal?: AbortSignal): Promise<Record<string, unknown>>;
    exportArchive?(input: FleetPanelArchiveExportInput, signal?: AbortSignal): Promise<FleetPanelArchiveFile>;
    importArchive?(input: FleetPanelArchiveImportInput, signal?: AbortSignal): Promise<void>;
    retry?(): Promise<void>;
    loadMemberTrace?(teamId: string, memberId: string, signal?: AbortSignal): Promise<FleetPanelMemberTrace>;
    loadResource?(teamId: string, resourceId: string, signal?: AbortSignal, revisionId?: string): Promise<FleetPanelResourceContent>;
}
export declare const FLEET_PANEL_SOURCE_SERVICE = "fleetPanelSource";
export declare const FLEET_PANEL_SLOTS: {
    readonly tool: "fleet.panel.tool";
    readonly sidebar: "fleet.panel.sidebar";
    readonly sidebarSection: "fleet.panel.sidebar.section";
    readonly main: "fleet.panel.main";
    readonly mainAction: "fleet.panel.main.action";
    readonly composerAction: "fleet.panel.composer.action";
    readonly messageText: "fleet.message.text";
    readonly messageBlock: "fleet.message.block";
    readonly messageAction: "fleet.message.action";
    readonly resourcePreview: "fleet.resource.preview";
    readonly resourceDiff: "fleet.resource.diff";
};
/** Current Team directory shared with root-level Fleet entry surfaces. */
export declare function getFleetTeamDirectorySnapshot(): FleetPanelTeamDirectory;
export declare function subscribeFleetTeamDirectory(listener: () => void): () => void;
interface PanelRenderOptions {
    readonly entryKey?: string;
    readonly fallback?: ReactNode;
}
export type FleetPanelRenderSlot = (name: string, owner: Record<string, unknown>, options?: PanelRenderOptions) => ReactNode;
export interface FleetPanelToolOwner {
    readonly activeTool: string;
    readonly disabled?: boolean;
    readonly selectTool: (tool: string) => void;
}
export interface FleetPanelPaneOwner {
    readonly sessionId: string;
    readonly fleet: FleetPanelSnapshot;
    readonly snapshot: FleetPanelTeamSnapshot;
    readonly activeItem: string;
    readonly selectItem: (item: string) => void;
    readonly showMemberDetails: (memberId: string) => void;
    readonly openResource: (resourceId: string) => void;
    readonly uploadResource?: (file: File) => Promise<void>;
    readonly controlTeam?: (action: FleetPanelTeamControlInput['action'], summary?: string) => Promise<void>;
    readonly controlMember?: (memberId: string, action: FleetPanelMemberControlInput['action']) => Promise<void>;
    readonly exportTeam?: FleetPanelSource['exportTeam'];
    readonly exportArchive?: (teamId: string, includeWorkspace: boolean) => Promise<FleetPanelArchiveFile>;
    readonly importArchive?: (file: File, projectRoot: string, mode: 'copy' | 'restore') => Promise<void>;
    readonly draft: string;
    readonly urgent: boolean;
    readonly sending: boolean;
    readonly sendError: string | null;
    readonly setDraft: (draft: string) => void;
    readonly setUrgent: (urgent: boolean) => void;
    readonly sendMessage: () => void;
    readonly loadMemberTrace?: FleetPanelSource['loadMemberTrace'];
    readonly loadResource?: FleetPanelSource['loadResource'];
    readonly openNavigation: () => void;
    readonly showTeamDirectory: () => void;
    readonly selectTeam: (teamId: string) => void;
    readonly renderPanelSlot: FleetPanelRenderSlot;
    readonly useSessions: FleetSnapshotSelectorHook;
    readonly nativeContext: FleetNativeContext;
    readonly t: (key: string, values?: Readonly<Record<string, unknown>>) => string;
    readonly SessionProvider: ComponentType<FleetTargetSessionProviderProps>;
}
export interface FleetPanelHomeOwner {
    readonly sessionId: string;
    readonly fleet: FleetPanelSnapshot;
    readonly focusedTeamId?: string;
    readonly selectTeam: (teamId: string) => void;
    readonly openTeamMessages: (teamId: string) => void;
    readonly controlTeamById?: (teamId: string, action: FleetPanelTeamControlInput['action'], summary?: string) => Promise<void>;
    readonly exportTeam?: FleetPanelSource['exportTeam'];
    readonly exportArchive?: (teamId: string, includeWorkspace: boolean) => Promise<FleetPanelArchiveFile>;
    readonly importArchive?: (file: File, projectRoot: string, mode: 'copy' | 'restore') => Promise<void>;
    readonly openNavigation: () => void;
    readonly renderPanelSlot: FleetPanelRenderSlot;
    readonly useSessions: FleetSnapshotSelectorHook;
    readonly nativeContext: FleetNativeContext;
    readonly t: (key: string, values?: Readonly<Record<string, unknown>>) => string;
    readonly SessionProvider: ComponentType<FleetTargetSessionProviderProps>;
}
export interface FleetPanelSidebarSectionOwner {
    readonly panel: FleetPanelHomeOwner | FleetPanelPaneOwner;
    readonly tool: 'home' | FleetPanelToolId;
}
export interface FleetPanelMessageOwner {
    readonly panel: FleetPanelPaneOwner;
    readonly conversation: FleetPanelConversation;
    readonly message: FleetPanelMessage;
    readonly sender: FleetChatMember;
}
export interface FleetPanelMessageTextOwner extends FleetPanelMessageOwner {
    readonly text: string;
}
export interface FleetPanelMessageBlockOwner extends FleetPanelMessageOwner {
    readonly block: FleetChatContentBlock;
    readonly index: number;
}
export interface FleetPanelResourcePreviewOwner {
    readonly panel: FleetPanelPaneOwner;
    readonly resource: FleetPanelResource;
}
export interface FleetPanelResourceDiffOwner {
    readonly panel: FleetPanelPaneOwner;
    readonly resource: FleetPanelResource;
    readonly revision: FleetPanelResourceRevision;
}
interface FleetTeamPanelProps {
    readonly sessionId: string;
    readonly source?: FleetPanelSource;
    readonly renderSlot: FleetPanelRenderSlot;
    readonly useSessions: FleetSnapshotSelectorHook;
    readonly t: (key: string, values?: Readonly<Record<string, unknown>>) => string;
    readonly nativeContext: FleetNativeContext;
    readonly SessionProvider: ComponentType<FleetTargetSessionProviderProps>;
}
interface FleetTargetSessionProviderProps {
    readonly sessionId?: string;
    readonly empty?: () => ReactNode;
    readonly children: (sessionId: string) => ReactNode;
}
type FleetSnapshotSelectorHook = <Selection>(selector: (snapshot: any) => Selection, equality?: (left: Selection, right: Selection) => boolean) => Selection;
interface FleetNativeSessionFace {
    getSnapshot(): any;
    subscribe(listener: () => void): () => void;
    open?(): Promise<void>;
    resync?(): Promise<void>;
    loadOlder(): Promise<void>;
}
interface FleetNativeContext {
    session(sessionId: string): FleetNativeSessionFace | undefined;
    openPath(path: string): Promise<void>;
    openFile(sessionId: string, path: string): Promise<void>;
    loadImage(sessionId: string, attachment: unknown): Promise<string>;
    fileMentions(owner: unknown): unknown;
}
/** Harmony decorator: retain the native component and its already-authorized child-slot runtime. */
export declare function withFleetNativeChatView<T extends ComponentType<any>>(ChatView: T): T;
interface FleetNativeChatRuntimePrimerProps {
    readonly renderSlot: (name: 'conversation.view', owner: Readonly<Record<string, unknown>>, options: {
        readonly only: string;
    }) => ReactNode;
    readonly inspect: unknown;
    readonly onInspectDone: () => void;
}
/** One-frame offscreen native view that captures the authorized ChatView runtime after a direct Fleet restore. */
export declare function FleetNativeChatRuntimePrimer({ renderSlot, inspect, onInspectDone, }: FleetNativeChatRuntimePrimerProps): ReactElement | null;
/**
 * DSH keeps listed Session instances resident and currently exposes no public
 * close verb. Fleet opens non-foreground Sessions only for its read-only Agent
 * view, so release that extra history window when the view goes away. Every
 * field is feature-detected to keep a future native close implementation free
 * to replace this compatibility path.
 */
export declare function releaseFleetNativeSessionWindow(session: FleetNativeSessionFace): boolean;
/** Keep local navigation valid when a live Team snapshot removes or replaces an item. */
export declare function resolveFleetPanelItem(team: FleetPanelTeamSnapshot, tool: string, requested: string | undefined): string;
export declare function FleetTeamPanel({ sessionId, source, renderSlot, useSessions, nativeContext, SessionProvider, t, }: FleetTeamPanelProps): ReactElement;
export declare function FleetPanelToolButton({ owner, tool, label, children }: {
    readonly owner: FleetPanelToolOwner;
    readonly tool: string;
    readonly label: string;
    readonly children: ReactNode;
}): ReactElement;
export interface FleetMemberMentionSegment {
    readonly text: string;
    readonly member?: FleetPanelMember;
}
export declare function splitFleetMemberMentions(text: string, members: readonly FleetPanelMember[]): readonly FleetMemberMentionSegment[];
export interface FleetActiveMentionQuery {
    readonly start: number;
    readonly end: number;
    readonly query: string;
}
export declare function activeFleetMentionQuery(text: string, caret: number): FleetActiveMentionQuery | undefined;
export declare function insertFleetMemberMention(text: string, mention: FleetActiveMentionQuery, memberName: string): {
    readonly text: string;
    readonly caret: number;
};
export declare function fleetResourcePreviewKind(resource: Pick<FleetPanelResource, 'name' | 'path' | 'mediaType'>): 'markdown' | 'text' | undefined;
interface SlotRegistrationOptions {
    readonly name: string;
    readonly id?: string;
    readonly key?: string;
    readonly order?: number;
    readonly label?: () => string;
    readonly locale?: string;
    readonly children?: Readonly<Record<string, {
        readonly kind: 'single' | 'list' | 'keyed';
        readonly scope: 'session';
    }>>;
    readonly inject?: (sessionId: string) => Record<string, unknown>;
}
interface FleetPanelSlots {
    inject(name: string, register: () => unknown): void;
    register(options: SlotRegistrationOptions, component: ComponentType<any>): unknown;
}
interface FleetPanelClientContext {
    readonly slots: FleetPanelSlots;
    readonly sessions?: FleetMetaClientSessions;
    readonly workspaces?: FleetMetaClientWorkspaces;
    readonly remote?: {
        $mount(contribution: typeof FLEET_WEB_REMOTE): Promise<() => Promise<void>>;
    };
    readonly typert: {
        register(contribution: typeof FLEET_WEB_PEER_LOCAL): () => Promise<void>;
    };
    inject<T extends object>(services: readonly string[], callback: (ctx: FleetPanelClientContext & T) => void): unknown;
    get?(name: string): unknown;
    provide?(name: string, value: unknown): () => void;
}
export interface FleetModelCatalogModel {
    readonly id: string;
    readonly name: string;
    readonly description?: string;
}
export interface FleetModelProviderGroup {
    readonly id: string;
    readonly name: string;
    readonly models: readonly FleetModelCatalogModel[];
}
export interface FleetModelDirectoryState {
    readonly current: {
        readonly provider: string;
        readonly model: string;
    } | null;
    readonly routable: boolean | null;
    readonly groups: readonly FleetModelProviderGroup[];
    readonly failures: readonly unknown[];
    readonly status: 'idle' | 'loading' | 'ready' | 'selecting' | 'error';
    readonly error: string | null;
}
export interface FleetModelDirectory {
    readonly store: {
        getSnapshot(): FleetModelDirectoryState;
        subscribe(listener: () => void): () => void;
    };
    load(): Promise<unknown>;
}
export declare function getFleetModelDirectory(sessionId: string | undefined): FleetModelDirectory | undefined;
export declare const inject: readonly ["slots", "sessions", "workspaces", "remote", "typert"];
export declare function apply(ctx: FleetPanelClientContext): Promise<() => Promise<void>>;
export {};
//# sourceMappingURL=team-panel.d.ts.map