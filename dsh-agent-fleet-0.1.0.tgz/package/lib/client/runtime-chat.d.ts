import type { ReactElement, ReactNode } from 'react';
import { HoverHint } from 'dsh-hover-hint';
export declare const FleetInfoHint: typeof HoverHint;
export type FleetPresence = 'active' | 'busy' | 'waiting' | 'error' | 'offline' | 'unknown';
export type FleetConversationKind = 'channel' | 'direct' | 'cross-team' | 'context';
export type FleetMessageDeliveryState = 'sending' | 'sent' | 'failed';
export interface FleetChatMember {
    readonly id: string;
    readonly name: string;
    readonly role: string;
    readonly color: string;
    readonly presence?: FleetPresence;
    readonly operator?: boolean;
}
export interface FleetChatAvatarProps {
    readonly member: FleetChatMember;
    readonly size?: number;
    readonly showPresence?: boolean;
}
export interface FleetConversationHeaderProps {
    readonly kind: FleetConversationKind;
    readonly name: string;
    readonly description?: string;
    readonly memberCount?: number;
    readonly activeCount?: number;
    readonly peer?: FleetChatMember;
    readonly meta?: ReactNode;
    readonly actions?: ReactNode;
}
export interface FleetChatMessageProps {
    readonly id: string;
    readonly sender: FleetChatMember;
    readonly sentAt: string;
    /** Serializable content that a human-facing composer or connected tool can produce. */
    readonly content: readonly FleetChatContentBlock[];
    readonly compact?: boolean;
    readonly deliveryState?: FleetMessageDeliveryState;
    readonly operatorLabel?: string;
    /** Optional integration-owned avatar treatment, such as a member profile popover. */
    readonly avatar?: ReactNode;
    /** Integration uses the official MessageText primitive here. */
    readonly renderText?: (text: string) => ReactNode;
    /** Integration uses the official conversation image slot here. */
    readonly renderImage?: (image: FleetChatImageBlock) => ReactNode;
    readonly renderMention?: (mention: FleetChatMentionBlock) => ReactNode | undefined;
    readonly renderBlock?: (block: FleetChatContentBlock, index: number) => ReactNode | undefined;
    readonly onOpenResource?: (resource: FleetChatResourceBlock) => void;
    readonly receipt?: FleetChatReadReceiptData;
    readonly actions?: ReactNode;
}
export interface FleetChatReadReceiptData {
    readonly readMembers: readonly FleetChatMember[];
    readonly unreadMembers: readonly FleetChatMember[];
}
export interface FleetChatImageBlock {
    readonly type: 'image';
    readonly attachmentId: string;
    readonly mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
    readonly name?: string;
    readonly bytes?: number;
    readonly width?: number;
    readonly height?: number;
}
export interface FleetChatResourceBlock {
    readonly type: 'resource';
    readonly id: string;
    readonly label: string;
    readonly mediaType?: string;
    readonly size?: number;
}
export interface FleetChatMentionBlock {
    readonly type: 'mention';
    readonly memberId: string;
    /** Snapshot label retained with the message even if the member is renamed. */
    readonly label: string;
}
export interface FleetChatExtensionBlock {
    readonly type: `extension:${string}`;
    readonly data: Readonly<Record<string, unknown>>;
}
export type FleetChatContentBlock = {
    readonly type: 'text';
    readonly text: string;
} | FleetChatImageBlock | FleetChatResourceBlock | FleetChatMentionBlock | FleetChatExtensionBlock;
export interface FleetChatDividerProps {
    readonly kind?: 'date' | 'unread';
    readonly children: ReactNode;
}
export interface FleetChatNoticeProps {
    readonly children: ReactNode;
}
export declare function FleetChatAvatar({ member, size, showPresence }: FleetChatAvatarProps): ReactElement;
export declare function FleetPresenceLabel({ presence, label }: {
    readonly presence: FleetPresence;
    readonly label?: string;
}): ReactElement;
export declare function FleetChatReadReceipt({ readMembers, unreadMembers }: FleetChatReadReceiptData): ReactElement | null;
export declare function FleetConversationHeader(props: FleetConversationHeaderProps): ReactElement;
export declare function FleetChatMessage({ id, sender, sentAt, content, compact, deliveryState, operatorLabel, avatar, renderText, renderImage, renderMention, renderBlock, onOpenResource, receipt, actions, }: FleetChatMessageProps): ReactElement;
export declare function FleetChatDivider({ kind, children }: FleetChatDividerProps): ReactElement;
export declare function FleetChatNotice({ children }: FleetChatNoticeProps): ReactElement;
//# sourceMappingURL=runtime-chat.d.ts.map