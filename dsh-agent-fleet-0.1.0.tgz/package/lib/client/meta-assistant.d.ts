import type { ComponentType, ReactElement } from 'react';
interface MetaSessionListSnapshot {
    readonly current?: string;
    readonly byId: Readonly<Record<string, {
        readonly cwd?: string;
    }>>;
}
interface MetaSessionBinding {
    readonly session: {
        rename(title: string): Promise<unknown>;
    };
}
export interface FleetMetaClientSessions {
    readonly list: {
        getSnapshot(): MetaSessionListSnapshot;
        subscribe(listener: () => void): () => void;
    };
    create(options?: {
        readonly cwd?: string;
    }): Promise<string>;
    open(sessionId: string): void;
    binding(sessionId: string): MetaSessionBinding | undefined;
}
export interface FleetMetaClientWorkspaces {
    readonly list: {
        getSnapshot(): {
            readonly archivedSessionIds: readonly string[];
        };
    };
    archiveSession(sessionId: string): Promise<void>;
}
export declare function configureFleetMetaAssistantClient(nextSessions: FleetMetaClientSessions | undefined, nextWorkspaces: FleetMetaClientWorkspaces | undefined): void;
export declare function FleetMetaAssistantPinnedRow(): ReactElement | null;
export declare function FleetMetaAssistantHeaderButton(): ReactElement | null;
/** Keep the dedicated Meta Session out of the ordinary Session tree without archiving it. */
export declare function withFleetMetaWorkspaceBrowser(WorkspaceBrowser: ComponentType<Record<string, unknown>>): ComponentType<Record<string, unknown>>;
/** Present a blank Meta Session as an established conversation rather than the new-Session Hero. */
export declare function withFleetMetaConversationRoot(ConversationRoot: ComponentType<Record<string, unknown>>): ComponentType<Record<string, unknown>>;
export {};
//# sourceMappingURL=meta-assistant.d.ts.map