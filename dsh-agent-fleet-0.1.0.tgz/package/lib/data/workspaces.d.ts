import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetArchiveRegistry } from '../archive.js';
import type { FleetRunService } from '../run.js';
export declare const FLEET_WORKSPACE_STATE_NAMESPACE = "workspaces";
export declare const FLEET_WORKSPACE_ARCHIVE_CONTRIBUTOR = "fleet.workspaces";
export type FleetWorkspaceAccess = 'read' | 'write';
export interface FleetWorkspace {
    readonly id: string;
    readonly name: string;
    readonly path: string;
    readonly createdBy: string;
    readonly createdAt: string;
}
export interface FleetWorkspaceMount {
    readonly workspaceId: string;
    readonly access: FleetWorkspaceAccess;
}
export interface FleetWorkspaceState {
    readonly version: 1;
    readonly workspaces: readonly FleetWorkspace[];
    /** Missing member keys inherit the Team's primary project workspace. */
    readonly members: Readonly<Record<string, readonly FleetWorkspaceMount[]>>;
}
export interface FleetResolvedWorkspaceMount extends FleetWorkspace {
    readonly access: FleetWorkspaceAccess;
    readonly builtIn: boolean;
}
export declare function parseFleetWorkspaceState(value: JsonValue | undefined): FleetWorkspaceState;
export declare class FleetWorkspaceService {
    private readonly runs;
    private readonly states;
    constructor(runs: FleetRunService);
    state(teamId: string): FleetWorkspaceState;
    workspaces(teamId: string): FleetWorkspace[];
    workspace(teamId: string, workspaceId: string): FleetWorkspace;
    resolvePath(teamId: string, path: string): string;
    mounts(teamId: string, member: string): FleetResolvedWorkspaceMount[];
    attach(teamId: string, actor: string, input: {
        readonly name: string;
        readonly path: string;
    }): FleetWorkspace;
    detach(teamId: string, workspaceId: string): void;
    assign(teamId: string, member: string, mounts: readonly FleetWorkspaceMount[]): FleetResolvedWorkspaceMount[];
    restore(teamId: string, state: FleetWorkspaceState): void;
    private projectWorkspace;
    private requireMember;
    private save;
}
export declare function installWorkspaceArchive(service: FleetWorkspaceService, archives: FleetArchiveRegistry): () => void;
export declare function applyWorkspaces(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetWorkspaces: FleetWorkspaceService;
    }
}
//# sourceMappingURL=workspaces.d.ts.map