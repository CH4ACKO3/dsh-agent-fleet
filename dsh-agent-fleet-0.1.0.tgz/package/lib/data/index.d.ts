import type { Context } from '@deepseek-ai/cordis';
export * from './documents.js';
export * from './workspaces.js';
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map