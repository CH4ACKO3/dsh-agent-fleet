import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-tools';
import type { FleetRunService } from '../run.js';
export declare const FLEET_DOCUMENT_STATE_NAMESPACE = "documents";
export interface FleetDocumentVersion {
    readonly version: number;
    readonly updatedBy: string;
    readonly updatedAt: string;
}
export interface FleetDocumentComment {
    readonly id: string;
    readonly author: string;
    readonly text: string;
    readonly parentId?: string;
    readonly resolved: boolean;
    readonly createdAt: string;
    readonly resolvedAt?: string;
    readonly resolvedBy?: string;
}
export interface FleetDocument {
    readonly id: string;
    readonly name: string;
    readonly title: string;
    readonly path: string;
    readonly content: string;
    readonly version: number;
    readonly versions: FleetDocumentVersion[];
    readonly comments: FleetDocumentComment[];
    readonly createdBy: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
interface FleetDocumentMetadata extends Omit<FleetDocument, 'content' | 'path'> {
}
export interface FleetDocumentState {
    readonly version: 1;
    readonly documents: readonly FleetDocumentMetadata[];
}
export interface FleetDocumentFiles {
    exists(path: string, signal?: AbortSignal): Promise<boolean>;
    read(path: string, signal?: AbortSignal): Promise<string>;
    write(path: string, content: string, signal?: AbortSignal): Promise<void>;
}
export declare function parseFleetDocumentState(value: JsonValue | undefined): FleetDocumentState;
export declare class FleetDocumentService {
    private readonly runs;
    private readonly states;
    private readonly pending;
    constructor(runs: FleetRunService);
    state(teamId: string): FleetDocumentState;
    has(teamId: string, id: string): boolean;
    list(teamId: string, files: FleetDocumentFiles, query?: string, signal?: AbortSignal): Promise<FleetDocument[]>;
    get(teamId: string, id: string, files: FleetDocumentFiles, signal?: AbortSignal): Promise<FleetDocument>;
    create(teamId: string, actor: string, input: {
        readonly name: string;
        readonly title: string;
        readonly content?: string;
    }, files: FleetDocumentFiles, signal?: AbortSignal): Promise<FleetDocument>;
    update(teamId: string, actor: string, id: string, input: {
        readonly title?: string;
        readonly content?: string;
    }, files: FleetDocumentFiles, signal?: AbortSignal): Promise<FleetDocument>;
    comment(teamId: string, actor: string, id: string, value: string, files: FleetDocumentFiles, parentId?: string, signal?: AbortSignal): Promise<FleetDocument>;
    resolveComment(teamId: string, actor: string, id: string, commentId: string, files: FleetDocumentFiles, signal?: AbortSignal): Promise<FleetDocument>;
    revert(teamId: string, actor: string, id: string, targetVersion: number, files: FleetDocumentFiles, signal?: AbortSignal): Promise<FleetDocument>;
    private requireMetadata;
    private materialize;
    private documentsRoot;
    private documentPath;
    private versionPath;
    private ensureDirectories;
    private replace;
    private save;
    private exclusive;
}
export declare function applyDocuments(ctx: Context): void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        fleetDocuments: FleetDocumentService;
    }
}
export {};
//# sourceMappingURL=documents.d.ts.map